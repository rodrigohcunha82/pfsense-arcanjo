#!/bin/sh
#Váriaveis do servidor FTP para onde o backup sera enviado
HOST_FTP="sftp.arcanjofirewall.com.br"
USUARIO_FTP="bkparcanjo"
SENHA_FTP="YuArCanj0"
SERVER="`hostname`"
DMY="`date +%d_%m_%Y`"


# BACKUPEANDO

scp /cf/conf/config.xml /conf/backup/bkp/Backup-$SERVER-$DMY.xml

# Acessa o FTP e envia os arquivos de backup
echo "ENVIANDO DADOS PARA A PASTA FTP REMOTA"

ftp -pin $HOST_FTP << EOF
quote user $USUARIO_FTP
quote PASS $SENHA_FTP
bin
lcd /conf/backup/bkp/
put Backup-$SERVER-$DMY.xml
bye
EOF

#Apaga arquivo temporario

SERVER="`hostname`"
DMY="`date +%d_%m_%Y`"
rm -rf /conf/backup/bkp/Backup-$SERVER-$DMY.xml

